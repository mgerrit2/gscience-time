package com.gscience.local;

public class LocalEx {
    public static LocalEx instant = new LocalEx();


}
