package com.gscience.dateTime;

import java.time.DayOfWeek;
import java.time.LocalDate;

public class LocalDateEx {

    public static LocalDateEx instant = new LocalDateEx();

    /**
     * https://stackoverflow.com/questions/64027813/oracle-next-day-function-equivalent-in-java
     * @param value
     * @param day
     * @return
     */
    public LocalDate getNextDay(
            final LocalDate value,
            final DayOfWeek day
    )
    {
        int currentDay = value.getDayOfWeek().getValue();
        int expectedDay = day.getValue();
        if ( currentDay >= expectedDay )
        {
            expectedDay += 7;
        }
        return value.plusDays( expectedDay - currentDay );
    }
}
