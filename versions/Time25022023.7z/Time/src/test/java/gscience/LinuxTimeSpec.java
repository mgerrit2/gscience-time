package gscience;

import org.junit.jupiter.api.Test;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

public class LinuxTimeSpec {

    /**
     * to investigate
     * https://stackoverflow.com/questions/732034/getting-unixtime-in-java
     */
    @Test
    void linuxTime() {

        Clock clock = Clock.systemUTC();
        long unixTime = Instant.now(clock).getEpochSecond();
        System.out.println(unixTime);

    }
}
