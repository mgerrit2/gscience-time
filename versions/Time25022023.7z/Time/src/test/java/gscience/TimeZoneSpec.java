package gscience;

/**
 * https://www.baeldung.com/java-jvm-time-zone
 */
public class TimeZoneSpec {
}
