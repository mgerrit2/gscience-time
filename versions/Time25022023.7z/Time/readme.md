# GScience Time


- 
## Java VM
Project is converted to java 17


